﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
public class player : MonoBehaviour
{

    public KeyCode moveUpKey = KeyCode.UpArrow;
    public KeyCode moveDownKey = KeyCode.DownArrow;
    public KeyCode moveRightKey = KeyCode.RightArrow;
    public KeyCode moveLeftKey = KeyCode.LeftArrow;
    public KeyCode shotkey;
    bool canMoveUp = true;
    bool canMoveDown = true;
    bool canMoveLeft = true;
    bool canMoveRight = true;
    public float speed = 0.2f;
    float directionx = 0.0f;
    float directiony = 0.0f;
    public Text timeminutes;
    public Text timeseconds;
    public Text gameover;
    public GameObject rightshot;
    public GameObject leftshot;
    public float time = 100;
    public float minutes = 2;
    public float seconds = 30;
    bool left;
    bool right;
    void FixedUpdate()
    {
        Vector3 position = transform.localPosition; // creates a vector3 variable called position and sets it to transform.localPosition
        position.x += speed * directionx; // sets position.x to position.x + speed * direction
        position.y += speed * directiony; // sets position.x to position.x + speed * direction
        transform.localPosition = position;
        time = time - 1;
    }


    void Update()
    {
        
        if (time == 0 && seconds > 0)
        {
            seconds = seconds - 1;
            time = 100;
        }
        if (seconds == 0 && minutes > 0)
        {
            minutes = minutes - 1;
            seconds = 60;
        }
        if (minutes == 0 && seconds == 0 && time == 0)
        {
            gameover.gameObject.SetActive(true);
        }
        timeseconds.text = seconds.ToString();
        timeminutes.text = minutes.ToString();
        bool isUpPressed = Input.GetKey(moveUpKey);
        bool isDownPressed = Input.GetKey(moveDownKey);
        bool isLeftPressed = Input.GetKey(moveLeftKey);
        bool isRightPressed = Input.GetKey(moveRightKey);
        bool isshot = Input.GetKey(shotkey);
        if (isUpPressed && canMoveUp)
        {
            directiony = 1.0f;
        }
        else if (isDownPressed && canMoveDown)
        {
            directiony = -1.0f;
        }
        else if (isLeftPressed && canMoveLeft)
        {
            directionx = -1.0f;
            left = true;
            right = false;
        }
        else if (isRightPressed && canMoveRight)
        {
            directionx = 1.0f;
            left = false;
            right = right;
        }
        else if (isshot)
        {
            if (left)
            {
                leftshot.gameObject.SetActive(true);
            }
            else if (right)
            {
                rightshot.gameObject.SetActive(true);
            }
        }
        else
        {
            directionx = 0.0f;
            directiony = 0.0f;
        }
    }
    void OnCollisionEnter2D(Collision2D other)
    {
        bool isUpPressed = Input.GetKey(moveUpKey);
        bool isDownPressed = Input.GetKey(moveDownKey);
        bool isLeftPressed = Input.GetKey(moveLeftKey);
        bool isRightPressed = Input.GetKey(moveRightKey);
        if (gameObject.tag == "wall")
        {
            if (isUpPressed)
            {
                canMoveUp = false;
            }
            else if (isDownPressed)
            {
                canMoveDown = false;
            }
            else if (isLeftPressed)
            {
                canMoveLeft = false;
            }
            else if (isRightPressed)
            {
                canMoveRight = false;
            }
        }

    }
    void OnCollisionExit2D(Collision2D other)
    {
        switch (other.gameObject.name)
        {
            case "Top Wall":
                canMoveUp = true;
                break;
            case "Bottom Wall":
                canMoveDown = true;
                break;
        }
    }
}
